/**
 * Custom front-end script for SKT Lace.
 *
 * Handles tab-key focus trapping inside the mobile menu so keyboard
 * users can move in and out of the open menu cleanly.
 */
(function ($) {
	'use strict';

	$(function () {

		var menuToggle = document.querySelector('.menu-toggle');
		var navMenu    = document.querySelector('.menu');

		if (!menuToggle || !navMenu) {
			return;
		}

		var navMenuLinks      = navMenu.getElementsByTagName('a');
		var navMenuListItems  = navMenu.querySelectorAll('li');

		if (!navMenuLinks.length || !navMenuListItems.length) {
			return;
		}

		var nav_lastIndex   = navMenuLinks.length - 1;
		var topLevelItems   = document.querySelectorAll('.main-navigation > ul > li');
		var navLastParent   = topLevelItems.length ? topLevelItems.length - 1 : 0;

		var menuFocus, navToggleItem, focusBackward;

		document.addEventListener('menu_focusin', function () {
			menuFocus = document.activeElement;

			if (navToggleItem && menuFocus !== navMenuLinks[0]) {
				var lastParentLink = topLevelItems[navLastParent] && topLevelItems[navLastParent].querySelector('a');
				if (lastParentLink) {
					lastParentLink.focus();
				}
			}

			navToggleItem = (menuFocus === menuToggle);
		}, true);

		document.addEventListener('keydown', function (e) {
			focusBackward = !!(e.shiftKey && e.keyCode === 9);
		});

		Array.prototype.forEach.call(navMenuLinks, function (el) {
			el.addEventListener('blur', function (e) {
				if (!focusBackward && e.target === navMenuLinks[nav_lastIndex]) {
					menuToggle.focus();
				}
			});
		});

		menuToggle.addEventListener('blur', function () {
			if (focusBackward) {
				navMenuLinks[nav_lastIndex].focus();
			}
		});
	});

}(jQuery));


document.addEventListener('DOMContentLoaded', function () {

    const toggle = document.querySelector('.search-toggle');
    const header = document.querySelector('.header-sac');

    if (toggle && header) {

        toggle.addEventListener('click', function (e) {
            e.stopPropagation();
            header.classList.toggle('search-open');

            if (header.classList.contains('search-open')) {
                header.querySelector('.search-field').focus();
            }
        });

        document.addEventListener('click', function (e) {
            if (!header.contains(e.target)) {
                header.classList.remove('search-open');
            }
        });
    }

});