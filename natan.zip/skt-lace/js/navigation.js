/**
 * File navigation.js
 *
 * Handles toggling the navigation menu for small screens, dropdown sub-menus
 * (with caret toggle buttons injected automatically), keyboard accessibility
 * (tab/escape), and click-outside-to-close behavior.
 */
(function () {
	'use strict';

	function initSiteNavigation() {

		var siteNavigation = document.getElementById('site-navigation');
		if (!siteNavigation) {
			return;
		}

		var button = siteNavigation.getElementsByTagName('button')[0];
		if (typeof button === 'undefined') {
			return;
		}

		var menu = siteNavigation.getElementsByTagName('ul')[0];
		if (typeof menu === 'undefined') {
			button.style.display = 'none';
			return;
		}

		if (!menu.classList.contains('nav-menu')) {
			menu.classList.add('nav-menu');
		}

		// Make sure aria-expanded starts in a sane state.
		button.setAttribute('aria-expanded', 'false');

		/* -----------------------------------------------------------------
		 * 1. MAIN MOBILE TOGGLE (hamburger)
		 * --------------------------------------------------------------- */
		button.addEventListener('click', function (e) {
			e.stopPropagation();
			var willOpen = !siteNavigation.classList.contains('toggled');
			siteNavigation.classList.toggle('toggled');
			button.setAttribute('aria-expanded', willOpen ? 'true' : 'false');
			document.body.classList.toggle('menu-open', willOpen);
			if (!willOpen) {
				closeAllDropdowns();
			}
		});

		/* -----------------------------------------------------------------
		 * 2. CLICK-OUTSIDE TO CLOSE
		 * --------------------------------------------------------------- */
		document.addEventListener('click', function (event) {
			if (!siteNavigation.contains(event.target)) {
				if (siteNavigation.classList.contains('toggled')) {
					siteNavigation.classList.remove('toggled');
					button.setAttribute('aria-expanded', 'false');
					document.body.classList.remove('menu-open');
					closeAllDropdowns();
				}
			}
		});

		/* -----------------------------------------------------------------
		 * 3. ESCAPE KEY CLOSES MENU
		 * --------------------------------------------------------------- */
		document.addEventListener('keydown', function (e) {
			if (e.key === 'Escape' || e.keyCode === 27) {
				if (siteNavigation.classList.contains('toggled')) {
					siteNavigation.classList.remove('toggled');
					button.setAttribute('aria-expanded', 'false');
					document.body.classList.remove('menu-open');
					button.focus();
				}
				closeAllDropdowns();
			}
		});

		/* -----------------------------------------------------------------
		 * 4. INJECT DROPDOWN-TOGGLE CARETS
		 *    For every parent menu item add a small <button> caret so users
		 *    can open the sub-menu on touch / mobile without losing the link.
		 * --------------------------------------------------------------- */
		var parents = menu.querySelectorAll(
			'.menu-item-has-children, .page_item_has_children'
		);

		Array.prototype.forEach.call(parents, function (parent) {
			// avoid double injection
			if (parent.querySelector(':scope > .dropdown-toggle')) {
				return;
			}
			var toggle = document.createElement('button');
			toggle.className = 'dropdown-toggle';
			toggle.setAttribute('aria-expanded', 'false');
			toggle.setAttribute('aria-label', 'Open sub-menu');
			toggle.innerHTML = '<span class="dropdown-icon" aria-hidden="true"></span>';

			// place it right after the parent <a>
			var parentLink = parent.querySelector(':scope > a');
			if (parentLink && parentLink.nextSibling) {
				parent.insertBefore(toggle, parentLink.nextSibling);
			} else {
				parent.appendChild(toggle);
			}

			toggle.addEventListener('click', function (e) {
				e.preventDefault();
				e.stopPropagation();

				var li = this.parentNode;
				var isOpen = li.classList.contains('dropdown-open');

				// close sibling dropdowns at the same level
				var siblings = li.parentNode.children;
				for (var i = 0; i < siblings.length; i++) {
					if (siblings[i] !== li) {
						siblings[i].classList.remove('dropdown-open');
						var sibBtn = siblings[i].querySelector(':scope > .dropdown-toggle');
						if (sibBtn) {
							sibBtn.setAttribute('aria-expanded', 'false');
						}
					}
				}

				li.classList.toggle('dropdown-open');
				this.setAttribute('aria-expanded', isOpen ? 'false' : 'true');
			});
		});

		/* -----------------------------------------------------------------
		 * 5. KEYBOARD FOCUS — keep desktop hover-style dropdown open while
		 *    tab-navigating through it.
		 * --------------------------------------------------------------- */
		var links = menu.getElementsByTagName('a');

		function toggleFocus(event) {
			var self = this;
			while (self && !self.classList.contains('nav-menu')) {
				if (self.tagName && self.tagName.toLowerCase() === 'li') {
					if (event.type === 'focus') {
						self.classList.add('focus');
					} else if (event.type === 'blur') {
						self.classList.remove('focus');
					}
				}
				self = self.parentNode;
			}
		}

		for (var i = 0; i < links.length; i++) {
			links[i].addEventListener('focus', toggleFocus, true);
			links[i].addEventListener('blur',  toggleFocus, true);
		}

		/* -----------------------------------------------------------------
		 * Helpers
		 * --------------------------------------------------------------- */
		function closeAllDropdowns() {
			var openItems = menu.querySelectorAll('.dropdown-open');
			Array.prototype.forEach.call(openItems, function (li) {
				li.classList.remove('dropdown-open');
				var b = li.querySelector(':scope > .dropdown-toggle');
				if (b) {
					b.setAttribute('aria-expanded', 'false');
				}
			});
		}

		/* -----------------------------------------------------------------
		 * 6. RESET STATE ON RESIZE (desktop ↔ mobile)
		 * --------------------------------------------------------------- */
		var resizeTimer;
		window.addEventListener('resize', function () {
			clearTimeout(resizeTimer);
			resizeTimer = setTimeout(function () {
				if (window.innerWidth > 1024) {
					siteNavigation.classList.remove('toggled');
					button.setAttribute('aria-expanded', 'false');
					document.body.classList.remove('menu-open');
					closeAllDropdowns();
				}
			}, 150);
		});
	}

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', initSiteNavigation);
	} else {
		initSiteNavigation();
	}
}());