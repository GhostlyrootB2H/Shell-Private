<?php
/**
 * The template for displaying the front page.
 *
 * Falls back to a blog-style listing when the front page is set to
 * "Your latest posts" in Settings > Reading, otherwise outputs the
 * static page content selected as the homepage.
 *
 * @package SKT_Lace
 */

get_header(); ?>

<div class="container">
	<div id="content_navigator">
		<div class="page_content">
			<section class="site-main">
				<div class="blog-post">
				<?php
				if ( 'posts' === get_option( 'show_on_front' ) ) :

					if ( have_posts() ) :
						while ( have_posts() ) :
							the_post();
							get_template_part( 'content', get_post_format() );
						endwhile;

						the_posts_pagination(
							array(
								'mid_size'  => 2,
								'prev_text' => esc_html__( 'Back', 'skt-lace' ),
								'next_text' => esc_html__( 'Next', 'skt-lace' ),
							)
						);
					else :
						get_template_part( 'no-results' );
					endif;

				else :

					if ( have_posts() ) :
						while ( have_posts() ) :
							the_post();
							the_content();
						endwhile;
					else :
						get_template_part( 'no-results' );
					endif;

				endif;
				?>
				</div><!-- /.blog-post -->
			</section>
			<?php get_sidebar(); ?>
			<div class="clear"></div>
		</div><!-- /.page_content -->
	</div><!-- /#content_navigator -->
</div><!-- /.container -->

<?php get_footer(); ?>
