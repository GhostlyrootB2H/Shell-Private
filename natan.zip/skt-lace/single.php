<?php
/**
 * The template for displaying all single posts.
 *
 * @package SKT_Lace
 */

get_header(); ?>

<div class="container">
	<div id="content_navigator">
		<div class="page_content">
			<section class="site-main">
				<?php
				while ( have_posts() ) :
					the_post();

					get_template_part( 'content', 'single' );

					skt_lace_content_nav( 'nav-below' );

					if ( comments_open() || get_comments_number() ) {
						comments_template();
					}
				endwhile;
				?>
			</section>
			<?php get_sidebar(); ?>
			<div class="clear"></div>
		</div><!-- /.page_content -->
	</div><!-- /#content_navigator -->
</div><!-- /.container -->

<?php get_footer(); ?>
