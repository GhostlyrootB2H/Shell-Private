<?php
/**
 * The template for displaying comments.
 *
 * @package SKT_Lace
 */

if ( post_password_required() ) {
	return;
}
?>
<div id="comments" class="comments-area">

	<?php if ( have_comments() ) : ?>
		<h2 class="comments-title">
			<?php
			$comment_count = (int) get_comments_number();
			if ( 1 === $comment_count ) {
				/* translators: %s: post title. */
				printf( esc_html__( 'One thought on &ldquo;%s&rdquo;', 'skt-lace' ), '<span>' . esc_html( get_the_title() ) . '</span>' );
			} else {
				printf(
					/* translators: 1: number of comments, 2: post title. */
					esc_html( _nx( '%1$s thought on &ldquo;%2$s&rdquo;', '%1$s thoughts on &ldquo;%2$s&rdquo;', $comment_count, 'comments title', 'skt-lace' ) ),
					esc_html( number_format_i18n( $comment_count ) ),
					'<span>' . esc_html( get_the_title() ) . '</span>'
				);
			}
			?>
		</h2>

		<ol class="comment-list">
			<?php
			wp_list_comments(
				array(
					'style'      => 'ol',
					'short_ping' => true,
					'avatar_size' => 60,
				)
			);
			?>
		</ol>

		<?php
		the_comments_navigation(
			array(
				'prev_text' => esc_html__( 'Older Comments', 'skt-lace' ),
				'next_text' => esc_html__( 'Newer Comments', 'skt-lace' ),
			)
		);
		?>

		<?php if ( ! comments_open() ) : ?>
			<p class="no-comments"><?php esc_html_e( 'Comments are closed.', 'skt-lace' ); ?></p>
		<?php endif; ?>

	<?php endif; ?>

	<?php comment_form(); ?>

</div><!-- /#comments -->
