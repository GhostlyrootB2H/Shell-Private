<?php
/**
 * The template used for displaying single-post content.
 *
 * @package SKT_Lace
 */
?>
<article id="post-<?php the_ID(); ?>" <?php post_class( 'single-post' ); ?>>
	<div class="postmeta">
		<div class="post-date"><?php echo esc_html( get_the_date() ); ?></div>
		<div class="post-comment"> &nbsp;|&nbsp; <a href="<?php echo esc_url( get_comments_link() ); ?>"><?php comments_number(); ?></a></div>
		<div class="clear"></div>
	</div><!-- /.postmeta -->

	<div class="entry-content">
		<?php
		the_content();

		wp_link_pages(
			array(
				'before'      => '<div class="page-links"><span class="page-links-title">' . esc_html__( 'Pages:', 'skt-lace' ) . '</span>',
				'after'       => '</div>',
				'link_before' => '<span>',
				'link_after'  => '</span>',
				'pagelink'    => '<span class="screen-reader-text">' . esc_html__( 'Page', 'skt-lace' ) . ' </span>%',
				'separator'   => '<span class="screen-reader-text">, </span>',
			)
		);
		?>
		<div class="postmeta">
			<div class="post-tags"><?php the_tags(); ?></div>
			<div class="clear"></div>
		</div>
	</div><!-- /.entry-content -->

	<footer class="entry-meta">
		<?php edit_post_link(); ?>
	</footer>
</article>
