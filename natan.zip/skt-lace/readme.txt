=== SKT Lace ===

Contributors: sonalsinha21
Requires at least: 5.6
Tested up to: 7.0
Requires PHP: 7.0
Stable tag: 1.0
License: GPL-2.0-or-later
License URI: https://www.gnu.org/licenses/gpl-2.0.html
Tags: two-columns, right-sidebar, full-width-template, custom-background, custom-colors, custom-menu, sticky-post, theme-options, threaded-comments, featured-images, footer-widgets, translation-ready, rtl-language-support, custom-logo, editor-style, custom-header, blog, e-commerce
Template: skt-minimal

== Description ==

SKT Lace is a stylish WordPress theme. It is used for lacework, patchwork, embroidery, needlework, fabric ornamentation, and textile craftsmanship businesses. It suits boutiques, sewing studios, fashion designers, quilt makers, and handmade fabric stores. The theme features a responsive layout, WooCommerce compatibility, Elementor support, customizable sections, SEO friendly code, and one click demo import. Showcase intricate creations, decorative textiles, and artisan collections with an elegant website that attracts customers and highlights your creative expertise.

== Installation ==

1. Install and activate the parent theme "SKT Minimal" from Appearance > Themes > Add New.
2. In your admin panel, go to Appearance > Themes and click the Add New button.
3. Click Upload Theme and Choose File, then select the skt-lace.zip file. Click Install Now.
4. Click Activate to use your new theme right away.
5. Go to Appearance > Customize to upload your logo, set colors and configure header / banner options.

== Changelog ==

= 1.0 =
* Initial version release.

== Theme Resources ==

Theme is built using the following resource bundles:

* All JS files are within the /js folder of the theme.

*   SKT Themes self-designed images (GPL v2 or later):
	images/cart-image.png
	images/free-vs-pro.png
	images/icon-fb.png
	images/icon-in.png
	images/icon-insta.png
	images/icon-skt-templates.png
	images/icon-tw.png
	images/icon-youtube.png
	images/logo.png
	images/search-icon.png
	images/sktskill.jpg
	images/user-image.png

	Self-created by SKT Themes, licensed under GPL v2 or later.
	License URL: https://www.gnu.org/licenses/gpl-2.0.html
	
*   Details of images used in Screenshot:
	https://pxhere.com/en/photo/937042
	https://pxhere.com/en/photo/1267947	

	Image used from pxhere.com
	This site provides images under CC0 license
	CC0 license: https://creativecommons.org/share-your-work/public-domain/cc0 	

For any help you can mail us at support[at]sktthemes.com

== Credits & Copyright ==

SKT Lace is a child theme of SKT Minimal and as such uses the same open-source projects as its parent theme.
SKT Lace is distributed under the terms of the GNU GPL license version 2.0 or later.
License URL: https://www.gnu.org/licenses/gpl-2.0.html

* TGM Plugin Activation, Copyright Thomas Griffin, Gary Jones, Juliette Reinders Folmer
  License: GPL-2.0+
  Source: http://tgmpluginactivation.com/
