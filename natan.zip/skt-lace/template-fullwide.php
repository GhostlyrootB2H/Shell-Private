<?php
/**
 * Template Name: Full Wide
 *
 * @package SKT_Lace
 */

get_header(); ?>

<div class="container">
	<div class="page_content">
		<section id="sitefull">
			<?php
			if ( have_posts() ) :
				while ( have_posts() ) :
					the_post();
					?>
					<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
						<div class="entry-content">
							<?php
							the_content();

							wp_link_pages(
								array(
									'before'      => '<div class="page-links"><span class="page-links-title">' . esc_html__( 'Pages:', 'skt-lace' ) . '</span>',
									'after'       => '</div>',
									'link_before' => '<span>',
									'link_after'  => '</span>',
									'pagelink'    => '<span class="screen-reader-text">' . esc_html__( 'Page', 'skt-lace' ) . ' </span>%',
									'separator'   => '<span class="screen-reader-text">, </span>',
								)
							);

							if ( comments_open() || get_comments_number() ) {
								comments_template();
							}
							?>
						</div><!-- /.entry-content -->
					</article>
					<?php
				endwhile;
			endif;
			?>
		</section>
		<div class="clear"></div>
	</div><!-- /.page_content -->
</div><!-- /.container -->

<?php get_footer(); ?>
