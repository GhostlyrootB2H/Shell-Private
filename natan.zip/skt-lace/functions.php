<?php
/**
 * SKT Lace functions and definitions.
 *
 * Child theme of SKT Minimal.
 *
 * @package SKT_Lace
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Theme version constant — bump on every release.
 */
if ( ! defined( 'SKT_LACE_VERSION' ) ) {
	define( 'SKT_LACE_VERSION', '1.0' );
}

/**
 * URL constants used by the About Theme page.
 */
if ( ! defined( 'SKT_LACE_SKTTHEMES_URL' ) ) {
	define( 'SKT_LACE_SKTTHEMES_URL', 'https://www.sktthemes.org/' );
}
if ( ! defined( 'SKT_LACE_SKTTHEMES_PRO_THEME_URL' ) ) {
	define( 'SKT_LACE_SKTTHEMES_PRO_THEME_URL', 'https://www.sktthemes.org/shop/quilting-wordpress-theme/' );
}
if ( ! defined( 'SKT_LACE_SKTTHEMES_FREE_THEME_URL' ) ) {
	define( 'SKT_LACE_SKTTHEMES_FREE_THEME_URL', 'https://www.sktthemes.org/shop/skt-lace/' );
}
if ( ! defined( 'SKT_LACE_SKTTHEMES_THEME_DOC' ) ) {
	define( 'SKT_LACE_SKTTHEMES_THEME_DOC', 'https://www.sktthemesdemo.net/documentation/skt-minimal-doc/' );
}
if ( ! defined( 'SKT_LACE_SKTTHEMES_LIVE_DEMO' ) ) {
	define( 'SKT_LACE_SKTTHEMES_LIVE_DEMO', 'https://sktperfectdemo.com/themepack/skt-lace-pro/' );
}
if ( ! defined( 'SKT_LACE_SKTTHEMES_THEMES' ) ) {
	define( 'SKT_LACE_SKTTHEMES_THEMES', 'https://www.sktthemes.org/themes/' );
}

/**
 * Theme setup.
 */
if ( ! function_exists( 'skt_lace_setup' ) ) :
	function skt_lace_setup() {

		if ( ! isset( $GLOBALS['content_width'] ) ) {
			$GLOBALS['content_width'] = apply_filters( 'skt_lace_content_width', 640 );
		}

		load_child_theme_textdomain( 'skt-lace', get_stylesheet_directory() . '/languages' );

		add_theme_support( 'automatic-feed-links' );
		add_theme_support( 'title-tag' );
		add_theme_support( 'post-thumbnails' );
		add_post_type_support( 'page', 'excerpt' );

		// WooCommerce.
		add_theme_support( 'woocommerce' );
		add_theme_support( 'wc-product-gallery-zoom' );
		add_theme_support( 'wc-product-gallery-lightbox' );
		add_theme_support( 'wc-product-gallery-slider' );

		// Custom logo.
		add_theme_support(
			'custom-logo',
			array(
				'height'      => 60,
				'width'       => 155,
				'flex-height' => false,
				'flex-width'  => false,
			)
		);

		// Block editor enhancements.
		add_theme_support( 'wp-block-styles' );
		add_theme_support( 'responsive-embeds' );
		add_theme_support( 'align-wide' );

		// HTML5 markup support.
		add_theme_support(
			'html5',
			array(
				'search-form',
				'comment-form',
				'comment-list',
				'gallery',
				'caption',
				'style',
				'script',
				'navigation-widgets',
			)
		);

		// Editor style (from child theme).
		add_editor_style( 'editor-style.css' );

		// Custom background.
		add_theme_support(
			'custom-background',
			array(
				'default-color' => 'ffffff',
			)
		);

		// Navigation menus.
		register_nav_menus(
			array(
				'primary' => esc_html__( 'Primary Menu', 'skt-lace' ),
			)
		);
	}
endif;
add_action( 'after_setup_theme', 'skt_lace_setup' );

/**
 * Detach the parent theme's setup actions BEFORE they run.
 */
function skt_lace_unhook_parent_theme() {
	remove_action( 'after_setup_theme', 'skt_minimal_setup' );
}
add_action( 'after_setup_theme', 'skt_lace_unhook_parent_theme', 0 );

/**
 * Detach parent theme's admin / customizer / TGMPA / CSS hooks.
 */
function skt_lace_unhook_parent_features() {
	remove_action( 'admin_notices',      'skt_minimal_activation_notice' );
	remove_action( 'admin_menu',         'skt_minimal_abouttheme' );
	remove_action( 'customize_register', 'skt_minimal_customize_register' );
	remove_action( 'wp_enqueue_scripts', 'skt_minimal_custom_css' );
	remove_action( 'tgmpa_register',     'skt_minimal_register_required_plugins' );
}
add_action( 'init', 'skt_lace_unhook_parent_features' );

/**
 * Unregister the parent theme's sidebars.
 */
function skt_lace_unregister_parent_widgets_areas() {
	unregister_sidebar( 'sidebar-1' );
	unregister_sidebar( 'fc-1' );
	unregister_sidebar( 'fc-2' );
	unregister_sidebar( 'fc-3' );
	unregister_sidebar( 'fc-4' );
}
add_action( 'widgets_init', 'skt_lace_unregister_parent_widgets_areas', 11 );

/**
 * Register child-theme widget areas.
 */
function skt_lace_widgets_init() {

	register_sidebar(
		array(
			'name'          => esc_html__( 'Sidebar', 'skt-lace' ),
			'description'   => esc_html__( 'Appears on sidebar', 'skt-lace' ),
			'id'            => 'fc-pln-sidebar',
			'before_widget' => '<aside id="%1$s" class="widget %2$s">',
			'after_widget'  => '</aside>',
			'before_title'  => '<h3 class="widget-title titleborder"><span>',
			'after_title'   => '</span></h3>',
		)
	);

	for ( $i = 1; $i <= 4; $i++ ) {
		register_sidebar(
			array(
				/* translators: %d: footer column number. */
				'name'          => sprintf( esc_html__( 'Footer Column %d', 'skt-lace' ), $i ),
				'description'   => esc_html__( 'Appears on page footer', 'skt-lace' ),
				'id'            => 'fc-' . $i . '-rfl',
				'before_widget' => '<aside id="%1$s" class="widget %2$s">',
				'after_widget'  => '</aside>',
				'before_title'  => '<h5>',
				'after_title'   => '</h5>',
			)
		);
	}
}
add_action( 'widgets_init', 'skt_lace_widgets_init' );

/**
 * Enqueue child theme styles and scripts.
 *
 * Child's style.css is loaded under handle 'skt-lace-style'
 * so the responsive stylesheet's dependency resolves correctly.
 * Parent's style.css is NOT enqueued here — it's removed below.
 */
function skt_lace_enqueue_assets() {

	wp_enqueue_style(
		'skt-lace-style',
		get_stylesheet_directory_uri() . '/style.css',
		array(),
		SKT_LACE_VERSION
	);

	wp_enqueue_style(
		'skt-lace-responsive',
		get_stylesheet_directory_uri() . '/css/responsive.css',
		array( 'skt-lace-style' ),
		SKT_LACE_VERSION
	);

	// Dashicons on the front-end.
	wp_enqueue_style( 'dashicons' );

	// Comment reply on single posts.
	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}

	// Drop parent JS handles and ship child versions.
	wp_dequeue_script( 'skt-minimal-navigation' );
	wp_dequeue_script( 'skt-minimal-customscripts' );

	wp_enqueue_script(
		'skt-lace-navigation',
		get_stylesheet_directory_uri() . '/js/navigation.js',
		array(),
		SKT_LACE_VERSION,
		true
	);

	wp_enqueue_script(
		'skt-lace-custom',
		get_stylesheet_directory_uri() . '/js/custom.js',
		array( 'jquery' ),
		SKT_LACE_VERSION,
		true
	);
}
add_action( 'wp_enqueue_scripts', 'skt_lace_enqueue_assets', 20 );

function skt_lace_remove_parent_style() {
	global $wp_styles;

	$parent_style_url = get_template_directory_uri() . '/style.css';
	$child_style_url  = get_stylesheet_directory_uri() . '/style.css';

	foreach ( $wp_styles->registered as $handle => $style ) {
		// Don't touch our own handle.
		if ( 'skt-lace-style' === $handle ) {
			continue;
		}
		// Remove any other handle pointing to parent's OR child's style.css.
		if ( $style->src === $parent_style_url || $style->src === $child_style_url ) {
			wp_dequeue_style( $handle );
		}
	}
}
add_action( 'wp_enqueue_scripts', 'skt_lace_remove_parent_style', 999 );

/**
 * Admin notice CSS.
 */
function skt_lace_admin_notice_css() {
	wp_enqueue_style(
		'skt-lace-admin-style',
		get_stylesheet_directory_uri() . '/css/skt-lace-admin-style.css',
		array(),
		SKT_LACE_VERSION
	);
}
add_action( 'admin_enqueue_scripts', 'skt_lace_admin_notice_css' );

function skt_lace_dequeue_parent_style() {
	wp_dequeue_style( 'skt-minimal-main-style' );
	wp_deregister_style( 'skt-minimal-main-style' );
}
add_action( 'wp_enqueue_scripts', 'skt_lace_dequeue_parent_style', 20 );

/**
 * Admin script.
 */
function skt_lace_admin_style() {
	wp_enqueue_script(
		'skt-lace-admin-script',
		get_stylesheet_directory_uri() . '/js/skt-lace-admin-script.js',
		array(),
		SKT_LACE_VERSION,
		true
	);
}
add_action( 'admin_enqueue_scripts', 'skt_lace_admin_style' );

/**
 * About-page CSS (only on the About Theme screen).
 */
function skt_lace_about_page_css( $hook ) {
	if ( 'appearance_page_skt_lace_guide' !== $hook ) {
		return;
	}
	wp_enqueue_style(
		'skt-lace-about-page-style',
		get_stylesheet_directory_uri() . '/css/skt-lace-about-page-style.css',
		array(),
		SKT_LACE_VERSION
	);
}
add_action( 'admin_enqueue_scripts', 'skt_lace_about_page_css' );

/**
 * Activation notice on themes.php.
 */
function skt_lace_activation_notice() {

	if ( ! function_exists( 'get_current_screen' ) ) {
		return;
	}

	$screen = get_current_screen();
	if ( ! $screen || 'themes' !== $screen->id ) {
		return;
	}

	if ( ! isset( $_GET['activated'] ) ) {
		return;
	}
	?>
	<div class="notice notice-info is-dismissible">
		<div class="skt-lace-notice-container">
			<div class="skt-lace-notice-img">
				<img src="<?php echo esc_url( get_stylesheet_directory_uri() . '/images/icon-skt-templates.png' ); ?>" alt="<?php esc_attr_e( 'SKT Templates', 'skt-lace' ); ?>" />
			</div>
			<div class="skt-lace-notice-content">
				<div class="skt-lace-notice-heading"><?php esc_html_e( 'Thank you for installing SKT Lace!', 'skt-lace' ); ?></div>
				<p class="largefont"><?php esc_html_e( 'SKT Lace comes with 200+ ready to use Elementor templates. Install the SKT Templates plugin to get started.', 'skt-lace' ); ?></p>
				<p>
					<a class="button button-primary" href="<?php echo esc_url( admin_url( 'themes.php?page=skt_lace_guide' ) ); ?>"><?php esc_html_e( 'Get Started', 'skt-lace' ); ?></a>
				</p>
			</div>
			<div class="skt-lace-clear"></div>
		</div>
	</div>
	<?php
}
add_action( 'admin_notices', 'skt_lace_activation_notice' );

/**
 * Custom logo wrapper.
 */
if ( ! function_exists( 'skt_lace_the_custom_logo' ) ) :
	function skt_lace_the_custom_logo() {
		if ( function_exists( 'the_custom_logo' ) ) {
			the_custom_logo();
		}
	}
endif;

/**
 * Add an `inner` body class on every non-front, non-home page.
 */
function skt_lace_body_classes( $classes ) {
	if ( ! is_home() && ! is_front_page() ) {
		$classes[] = 'inner';
	}
	return $classes;
}
add_filter( 'body_class', 'skt_lace_body_classes' );

/**
 * Register a custom block style on `core/quote`.
 */
function skt_lace_register_block_styles() {

	if ( ! function_exists( 'register_block_style' ) ) {
		return;
	}

	register_block_style(
		'core/quote',
		array(
			'name'  => 'skt-lace-plain',
			'label' => esc_html__( 'Plain', 'skt-lace' ),
		)
	);
}
add_action( 'init', 'skt_lace_register_block_styles' );

/**
 * Register the theme block-pattern category.
 */
function skt_lace_register_block_pattern_category() {

	if ( ! function_exists( 'register_block_pattern_category' ) ) {
		return;
	}

	register_block_pattern_category(
		'skt-lace',
		array( 'label' => esc_html__( 'SKT Lace', 'skt-lace' ) )
	);
}
add_action( 'init', 'skt_lace_register_block_pattern_category' );

/**
 * Post-navigation helper.
 */
if ( ! function_exists( 'skt_lace_content_nav' ) ) {
	function skt_lace_content_nav( $nav_id = 'nav-below' ) {
		the_post_navigation(
			array(
				'prev_text' => '<span class="meta-nav">&laquo;</span> %title',
				'next_text' => '%title <span class="meta-nav">&raquo;</span>',
			)
		);
	}
}

/**
 * Includes.
 */
require get_stylesheet_directory() . '/inc/customizer.php';
require get_stylesheet_directory() . '/inc/about-themes.php';

/**
 * Optional plugin recommendations via TGMPA.
 */
if ( ! class_exists( 'TGM_Plugin_Activation', false ) ) {
	require_once get_stylesheet_directory() . '/class-tgm-plugin-activation.php';
}

add_action( 'tgmpa_register', 'skt_lace_register_recommended_plugins' );

function skt_lace_register_recommended_plugins() {

	$plugins = array(
		array(
			'name'     => 'SKT Templates',
			'slug'     => 'skt-templates',
			'required' => false,
		),
	);

	$config = array(
		'id'           => 'skt-lace-tgmpa',
		'default_path' => '',
		'menu'         => 'skt-install-plugins',
		'parent_slug'  => 'themes.php',
		'capability'   => 'edit_theme_options',
		'has_notices'  => true,
		'dismissable'  => true,
		'is_automatic' => false,
	);

	tgmpa( $plugins, $config );
}

add_action( 'wp', 'skt_lace_remove_shop_page_title' );

function skt_lace_remove_shop_page_title() {
    if ( class_exists( 'WooCommerce' ) && is_shop() ) {
        add_filter( 'woocommerce_show_page_title', '__return_false' );
    }
}

function skt_lace_override_fonts() {
    wp_dequeue_style('skt-minimal-fonts');
    wp_deregister_style('skt-minimal-fonts');
    
    $font_family = array(
        'Roboto Condensed:300,400,600,700,800,900',
        'Lato:100,100i,300,300i,400,400i,700,700i,900,900i',
        'Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i',
        'Open Sans:300,300i,400,400i,600,600i,700,700i,800,800i',
        'Assistant:200,300,400,600,700,800',
        'Merriweather:300,300i,400,400i,700,700i,900,900i',
        'Poppins:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i',
        'Playfair Display:400,400i,500,500i,600,600i,700,700i,800,800i,900,900i',
		'Anton:400,400i'
    );
    $query_args = array(
        'family' => urlencode(implode('|', $font_family)),
    );
    $font_url = add_query_arg($query_args, '//fonts.googleapis.com/css');
    wp_enqueue_style('skt-lace-custom-fonts', $font_url, array(), null);
}
add_action('wp_enqueue_scripts', 'skt_lace_override_fonts', 99); 

function skt_lace_remove_parent_font() {
    wp_dequeue_style('skt-minimal-font');
    wp_deregister_style('skt-minimal-font');
}
add_action('wp_print_styles', 'skt_lace_remove_parent_font', 100);