<?php
/**
 * The sidebar containing the main widget area.
 *
 * @package SKT_Lace
 */

if ( ! is_active_sidebar( 'fc-pln-sidebar' ) ) {
	return;
}
?>
<div id="sidebar">
	<?php dynamic_sidebar( 'fc-pln-sidebar' ); ?>
</div><!-- /#sidebar -->
