<?php
/**
 * SKT Lace Theme Customizer.
 *
 * @package SKT_Lace
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Custom-header support.
 */
function skt_lace_custom_header_setup() {
	add_theme_support(
		'custom-header',
		apply_filters(
			'skt_lace_custom_header_args',
			array(
				'default-text-color' => '949494',
				'width'              => 1600,
				'height'             => 230,
				'flex-height'        => true,
				'flex-width'         => true,
				'wp-head-callback'   => 'skt_lace_header_style',
				'header-text'        => false,
			)
		)
	);
}
add_action( 'after_setup_theme', 'skt_lace_custom_header_setup' );

if ( ! function_exists( 'skt_lace_header_style' ) ) :
	/**
	 * Inline CSS for the header image when one is set.
	 */
	function skt_lace_header_style() {

		$header_image = get_header_image();

		if ( ! $header_image ) {
			return;
		}
		?>
		<style type="text/css" id="skt-lace-header-css">
			.header {
				background: url(<?php echo esc_url( $header_image ); ?>) no-repeat;
				background-position: center top;
				background-size: cover;
			}
		</style>
		<?php
	}
endif;

/**
 * Register Customizer settings, sections and controls.
 *
 * @param WP_Customize_Manager $wp_customize Customizer object.
 */
function skt_lace_customize_register( $wp_customize ) {

	/* Live preview for site title & description. */
	if ( $wp_customize->get_setting( 'blogname' ) ) {
		$wp_customize->get_setting( 'blogname' )->transport = 'postMessage';
	}
	if ( $wp_customize->get_setting( 'blogdescription' ) ) {
		$wp_customize->get_setting( 'blogdescription' )->transport = 'postMessage';
	}

	/* Theme accent / colour scheme. */
	$wp_customize->add_setting(
		'color_scheme',
		array(
			'default'           => '#33cacf',
			'sanitize_callback' => 'sanitize_hex_color',
			'transport'         => 'refresh',
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'color_scheme',
			array(
				'label'    => esc_html__( 'Color Scheme', 'skt-lace' ),
				'section'  => 'colors',
				'settings' => 'color_scheme',
			)
		)
	);

	$wp_customize->add_setting(
		'header_bg_color',
		array(
			'default'           => '#ffffff',
			'sanitize_callback' => 'sanitize_hex_color',
			'transport'         => 'refresh',
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'header_bg_color',
			array(
				'label'    => esc_html__( 'Header Background Color', 'skt-lace' ),
				'section'  => 'colors',
				'settings' => 'header_bg_color',
			)
		)
	);

	$wp_customize->add_setting(
		'footer_text_color',
		array(
			'default'           => '#1d1d1d',
			'sanitize_callback' => 'sanitize_hex_color',
			'transport'         => 'refresh',
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'footer_text_color',
			array(
				'label'    => esc_html__( 'Copyright Text Color', 'skt-lace' ),
				'section'  => 'colors',
				'settings' => 'footer_text_color',
			)
		)
	);

	/* Header Social section. */
	$wp_customize->add_section(
		'header_social',
		array(
			'title'    => esc_html__( 'Header Social Icons', 'skt-lace' ),
			'priority' => 30,
		)
	);
	
	$wp_customize->add_setting('fb_link_scl',array(
			'default'	=> null,
			'sanitize_callback'	=> 'esc_url_raw'	
	));
	
	$wp_customize->add_control('fb_link_scl',array(
			'label'	=> esc_html__('Facebook URL','skt-lace'),
			'section'	=> 'header_social',
			'setting'	=> 'fb_link_scl'
	));	
	$wp_customize->add_setting('youtube_link_scl',array(
			'default'	=> null,
			'sanitize_callback'	=> 'esc_url_raw'
	));
	
	$wp_customize->add_control('youtube_link_scl',array(
			'label'	=> esc_html__('YouTube URL','skt-lace'),
			'section'	=> 'header_social',
			'setting'	=> 'youtube_link_scl'
	));
	$wp_customize->add_setting('linked_link_scl',array(
			'default'	=> null,
			'sanitize_callback'	=> 'esc_url_raw'
	));
	$wp_customize->add_control('linked_link_scl',array(
			'label'	=> esc_html__('Linkedin URL','skt-lace'),
			'section'	=> 'header_social',
			'setting'	=> 'linked_link_scl'
	));
	$wp_customize->add_setting('insta_link_scl',array(
			'default'	=> null,
			'sanitize_callback'	=> 'esc_url_raw'
	));
	$wp_customize->add_control('insta_link_scl',array(
			'label'	=> esc_html__('Instagram URL','skt-lace'),
			'section'	=> 'header_social',
			'setting'	=> 'insta_link_scl'
	));	

	$wp_customize->add_setting(
		'hide_header_social',
		array(
			'sanitize_callback' => 'skt_lace_sanitize_checkbox',
			'default'           => true,
		)
	);
	$wp_customize->add_control(
		'hide_header_social',
		array(
			'section' => 'header_social',
			'label'   => esc_html__( 'Uncheck to display the header social icons.', 'skt-lace' ),
			'type'    => 'checkbox',
		)
	);
	
	/* Inner page banner. */
	$wp_customize->add_section(
		'inner_page_banner',
		array(
			'title'    => esc_html__( 'Inner Page Banner', 'skt-lace' ),
			'priority' => 30,
		)
	);

	$wp_customize->add_setting(
		'inner_page_banner_thumb',
		array(
			'default'           => '',
			'sanitize_callback' => 'esc_url_raw',
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Image_Control(
			$wp_customize,
			'inner_page_banner_thumb',
			array(
				'section'       => 'inner_page_banner',
				'label'         => esc_html__( 'Upload Banner Image', 'skt-lace' ),
				'settings'      => 'inner_page_banner_thumb',
				'button_labels' => array(
					'select' => esc_html__( 'Select Image', 'skt-lace' ),
					'remove' => esc_html__( 'Remove Image', 'skt-lace' ),
					'change' => esc_html__( 'Change Image', 'skt-lace' ),
				),
			)
		)
	);

	$wp_customize->add_setting(
		'inner_page_banner_option',
		array(
			'sanitize_callback' => 'skt_lace_sanitize_checkbox',
			'default'           => true,
		)
	);
	$wp_customize->add_control(
		'inner_page_banner_option',
		array(
			'section' => 'inner_page_banner',
			'label'   => esc_html__( 'Uncheck to show the banner on inner pages. For a unique banner per page, keep this option unchecked and set a Featured Image. Recommended size: 1400 × 300 px.', 'skt-lace' ),
			'type'    => 'checkbox',
		)
	);

	/* Inner post / archive banner. */
	$wp_customize->add_section(
		'inner_post_banner',
		array(
			'title'    => esc_html__( 'Post & Archive Banner', 'skt-lace' ),
			'priority' => 30,
		)
	);

	$wp_customize->add_setting(
		'inner_post_banner_thumb',
		array(
			'default'           => '',
			'sanitize_callback' => 'esc_url_raw',
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Image_Control(
			$wp_customize,
			'inner_post_banner_thumb',
			array(
				'section'       => 'inner_post_banner',
				'label'         => esc_html__( 'Upload Banner Image', 'skt-lace' ),
				'settings'      => 'inner_post_banner_thumb',
				'button_labels' => array(
					'select' => esc_html__( 'Select Image', 'skt-lace' ),
					'remove' => esc_html__( 'Remove Image', 'skt-lace' ),
					'change' => esc_html__( 'Change Image', 'skt-lace' ),
				),
			)
		)
	);

	$wp_customize->add_setting(
		'inner_post_banner_option',
		array(
			'sanitize_callback' => 'skt_lace_sanitize_checkbox',
			'default'           => true,
		)
	);
	$wp_customize->add_control(
		'inner_post_banner_option',
		array(
			'section' => 'inner_post_banner',
			'label'   => esc_html__( 'Uncheck to show the banner on category, archive, and single post pages. For a unique banner per post, keep this option unchecked and set a Featured Image. Recommended size: 1400 × 300 px.', 'skt-lace' ),
			'type'    => 'checkbox',
		)
	);

	/* Footer copyright text. */
	$wp_customize->add_section(
		'footer_text_copyright',
		array(
			'title'    => esc_html__( 'Copyright Text', 'skt-lace' ),
			'priority' => 30,
		)
	);

	$wp_customize->add_setting(
		'footer_text',
		array(
			'default'           => '',
			'sanitize_callback' => 'sanitize_text_field',
		)
	);
	$wp_customize->add_control(
		'footer_text',
		array(
			'label'   => esc_html__( 'Enter your copyright text.', 'skt-lace' ),
			'section' => 'footer_text_copyright',
			'type'    => 'text',
		)
	);
}
add_action( 'customize_register', 'skt_lace_customize_register' );

/**
 * Sanitize a checkbox value.
 *
 * @param mixed $checked Raw value.
 * @return bool
 */
function skt_lace_sanitize_checkbox( $checked ) {
	return ( ( isset( $checked ) && true === (bool) $checked ) ? true : false );
}

/**
 * Sanitize an integer.
 *
 * @param mixed $input Raw value.
 * @return int|null
 */
function skt_lace_sanitize_integer( $input ) {
	if ( is_numeric( $input ) ) {
		return intval( $input );
	}
	return null;
}

/**
 * Output inline CSS driven by the Customizer values.
 *
 * Hooked to wp_enqueue_scripts at priority 30 so it always runs
 * after the main responsive stylesheet is enqueued (priority 20).
 */
function skt_lace_customizer_inline_css() {

	$color           = sanitize_hex_color( get_theme_mod( 'color_scheme', '#33cacf' ) );
	$header_bg       = sanitize_hex_color( get_theme_mod( 'header_bg_color', '#ffffff' ) );
	$footer_color    = sanitize_hex_color( get_theme_mod( 'footer_text_color', '#1d1d1d' ) );

	$custom_css = '';

	if ( $color ) {
		$custom_css .= "
			#sidebar ul li a:hover,
			.blog_lists h4 a:hover,
			.recent-post h6 a:hover,
			.recent-post a:hover,
			.design-by a,
			.postmeta a:hover,
			.tagcloud a,
			.blocksbox:hover h3,
			.header-phone-number,
			#sidebar li a:hover
			{ color: {$color}; }

			#sidebar h2::after,
			#sidebar h3::after,
			#sidebar h4::after,
			#sidebar h5::after,
			#sidebar h6::after,
			#sidebar h6 #sidebar label::after,
			#sidebar .wp-block-search__label::after { background: {$color}; }

			#commentform input#submit:hover,
			.wpcf7 input[type='submit'],
			input.search-submit,
			.recent-post .morebtn:hover,
			.read-more-btn,
			.woocommerce-product-search button[type='submit'],
			.designs-thumb,
			.aboutmore,
			.service-thumb-box,
			.view-all-btn a:hover,
			.social-icons a:hover,
			.custom-cart-count
			{ background-color: {$color}; }

			.titleborder span:after,
			.sticky { border-bottom-color: {$color}; }
		";
	}

	if ( $header_bg ) {
		$custom_css .= " .header { background-color: {$header_bg}; }";
	}

	if ( $footer_color ) {
		$custom_css .= " .copyright-txt{ color: {$footer_color} !important; }";
	}

	if ( ! empty( $custom_css ) ) {
		wp_add_inline_style( 'skt-lace-responsive', $custom_css );
	}
}
add_action( 'wp_enqueue_scripts', 'skt_lace_customizer_inline_css', 30 );
