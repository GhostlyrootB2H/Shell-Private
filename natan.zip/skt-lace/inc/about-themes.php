<?php
/**
 * About Theme info screen, registered under Appearance > About Theme.
 *
 * @package SKT_Lace
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Register the About Theme menu page.
 */
function skt_lace_abouttheme() {
	add_theme_page(
		esc_html__( 'About Theme', 'skt-lace' ),
		esc_html__( 'About Theme', 'skt-lace' ),
		'edit_theme_options',
		'skt_lace_guide',
		'skt_lace_render_about_page'
	);
}
add_action( 'admin_menu', 'skt_lace_abouttheme' );

/**
 * Render the About Theme screen.
 */
function skt_lace_render_about_page() {
	?>
	<div class="wrapper-info">
		<div class="col-left">
			<div class="col-left-area">
				<?php esc_html_e( 'Theme Information', 'skt-lace' ); ?>
			</div>
			<p><?php esc_html_e( 'SKT Lace is a stylish WordPress theme. It is used for lacework, patchwork, embroidery, needlework, fabric ornamentation, and textile craftsmanship businesses. It suits boutiques, sewing studios, fashion designers, quilt makers, and handmade fabric stores. The theme features a responsive layout, WooCommerce compatibility, Elementor support, customizable sections, SEO friendly code, and one click demo import. Showcase intricate creations, decorative textiles, and artisan collections with an elegant website that attracts customers and highlights your creative expertise.', 'skt-lace' ); ?></p>

			<a href="<?php echo esc_url( SKT_LACE_SKTTHEMES_PRO_THEME_URL ); ?>" target="_blank" rel="noopener noreferrer">
				<img src="<?php echo esc_url( get_stylesheet_directory_uri() . '/images/free-vs-pro.png' ); ?>" alt="<?php esc_attr_e( 'Free Vs Pro', 'skt-lace' ); ?>" />
			</a>
		</div>

		<div class="col-right">
			<div class="centerbold">
				<hr />
				<a href="<?php echo esc_url( SKT_LACE_SKTTHEMES_LIVE_DEMO ); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'Live Demo', 'skt-lace' ); ?></a> |
				<a href="<?php echo esc_url( SKT_LACE_SKTTHEMES_PRO_THEME_URL ); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'Buy Pro', 'skt-lace' ); ?></a> |
				<a href="<?php echo esc_url( SKT_LACE_SKTTHEMES_THEME_DOC ); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'Documentation', 'skt-lace' ); ?></a>
				<div class="space5"></div>
				<hr />
				<a href="<?php echo esc_url( SKT_LACE_SKTTHEMES_THEMES ); ?>" target="_blank" rel="noopener noreferrer">
					<img src="<?php echo esc_url( get_stylesheet_directory_uri() . '/images/sktskill.jpg' ); ?>" alt="<?php esc_attr_e( 'SKT Themes', 'skt-lace' ); ?>" />
				</a>
			</div>
		</div>
	</div>
	<?php
}
