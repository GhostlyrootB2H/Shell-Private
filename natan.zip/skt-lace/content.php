<?php
/**
 * Default content template — used by index, archive, category, etc.
 *
 * @package SKT_Lace
 */
?>
<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

	<?php if ( has_post_thumbnail() && ! post_password_required() && ! is_attachment() ) : ?>
		<div class="post-thumb">
			<a href="<?php the_permalink(); ?>" rel="bookmark" aria-hidden="true" tabindex="-1">
				<?php the_post_thumbnail( 'large' ); ?>
			</a>
		</div>
	<?php endif; ?>

	<header class="entry-header">
		<?php
		if ( is_singular() ) {
			the_title( '<h1 class="entry-title">', '</h1>' );
		} else {
			the_title( sprintf( '<h2 class="entry-title"><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h2>' );
		}
		?>
		<div class="postmeta">
			<div class="post-date"><?php echo esc_html( get_the_date() ); ?></div>
			<div class="post-comment"> &nbsp;|&nbsp; <a href="<?php echo esc_url( get_comments_link() ); ?>"><?php comments_number(); ?></a></div>
			<div class="clear"></div>
		</div>
	</header>

	<div class="entry-content">
		<?php
		if ( is_singular() ) {
			the_content( esc_html__( 'Continue reading', 'skt-lace' ) );
		} else {
			the_excerpt();
		}

		wp_link_pages(
			array(
				'before'      => '<div class="page-links"><span class="page-links-title">' . esc_html__( 'Pages:', 'skt-lace' ) . '</span>',
				'after'       => '</div>',
				'link_before' => '<span>',
				'link_after'  => '</span>',
				'pagelink'    => '<span class="screen-reader-text">' . esc_html__( 'Page', 'skt-lace' ) . ' </span>%',
				'separator'   => '<span class="screen-reader-text">, </span>',
			)
		);
		?>
	</div>

	<?php if ( ! is_singular() ) : ?>
		<p class="rdmore"><a href="<?php the_permalink(); ?>"><?php esc_html_e( 'Read More', 'skt-lace' ); ?></a></p>
	<?php endif; ?>

</article>
