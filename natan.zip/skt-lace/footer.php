<?php
/**
 * The footer template.
 *
 * @package SKT_Lace
 */
?>

<div id="footer">
	<div id="footer-wrapper">
    	<div class="container footerlight">
		<div class="copyright-area">
			<?php
			$has_footer_widgets = is_active_sidebar( 'fc-1-rfl' )
				|| is_active_sidebar( 'fc-2-rfl' )
				|| is_active_sidebar( 'fc-3-rfl' )
				|| is_active_sidebar( 'fc-4-rfl' );

			if ( $has_footer_widgets ) :
				?>
				<div class="footerarea">
					<div class="container footer ftr-widg">
						<div class="footer-all">
 								<div class="rfl-row">
									<?php if ( is_active_sidebar( 'fc-1-rfl' ) ) : ?>
										<div class="cols-3 widget-column-1"><?php dynamic_sidebar( 'fc-1-rfl' ); ?></div>
									<?php endif; ?>
									<?php if ( is_active_sidebar( 'fc-2-rfl' ) ) : ?>
										<div class="cols-3 widget-column-2"><?php dynamic_sidebar( 'fc-2-rfl' ); ?></div>
									<?php endif; ?>
									<?php if ( is_active_sidebar( 'fc-3-rfl' ) ) : ?>
										<div class="cols-3 widget-column-3"><?php dynamic_sidebar( 'fc-3-rfl' ); ?></div>
									<?php endif; ?>
									<?php if ( is_active_sidebar( 'fc-4-rfl' ) ) : ?>
										<div class="cols-3 widget-column-4"><?php dynamic_sidebar( 'fc-4-rfl' ); ?></div>
									<?php endif; ?>
								</div>
								<div class="clear"></div>
							<div class="clear"></div>
						</div><!-- /.footer-all -->
					</div><!-- /.container -->
				</div><!-- /.footerarea -->
			<?php endif; ?>
		</div><!-- /.copyright-area -->
        </div>

		<div class="copyright-wrapper">
			<div class="container">
				<div class="copyright-txt">
					<?php
					if ( ! empty( $footer_text ) ) {
						echo esc_html( $footer_text ) . ' ';
					}
					bloginfo( 'name' );
					echo ' | ';
					/* translators: %s: theme author link. */
					printf(
						esc_html__( 'Theme By %s', 'skt-lace' ),
						'<a href="' . esc_url( SKT_LACE_SKTTHEMES_FREE_THEME_URL ) . '" rel="noopener" target="_blank">' . esc_html__( 'SKT Lace', 'skt-lace' ) . '</a>'
					);
					?>
				</div>
				<div class="clear"></div>
			</div>
		</div>
	</div><!-- /#footer-wrapper -->
</div><!-- /#footer -->

<?php wp_footer(); ?>
</body>
</html>