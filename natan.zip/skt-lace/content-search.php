<?php
/**
 * Template used for displaying individual search results.
 *
 * @package SKT_Lace
 */
?>
<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	<header class="entry-header">
		<?php the_title( sprintf( '<h2 class="entry-title"><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h2>' ); ?>
		<div class="postmeta">
			<div class="post-date"><?php echo esc_html( get_the_date() ); ?></div>
			<div class="clear"></div>
		</div>
	</header>

	<div class="entry-summary">
		<?php the_excerpt(); ?>
	</div>

	<p class="rdmore"><a href="<?php the_permalink(); ?>"><?php esc_html_e( 'Read More', 'skt-lace' ); ?></a></p>
</article>
