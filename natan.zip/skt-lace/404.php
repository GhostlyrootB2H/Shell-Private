<?php
/**
 * The template for displaying 404 pages (not found).
 *
 * @package SKT_Lace
 */

get_header(); ?>

<div class="container">
	<div id="content_navigator">
		<div class="page_content">
			<section class="site-main error-404 not-found">
				<header class="page-header">
					<h1 class="page-title"><?php esc_html_e( 'Oops! That page can&rsquo;t be found.', 'skt-lace' ); ?></h1>
				</header>

				<div class="page-content">
					<p><?php esc_html_e( 'It looks like nothing was found at this location. Maybe try a search?', 'skt-lace' ); ?></p>
					<?php get_search_form(); ?>
				</div>
			</section>
			<?php get_sidebar(); ?>
			<div class="clear"></div>
		</div><!-- /.page_content -->
	</div><!-- /#content_navigator -->
</div><!-- /.container -->

<?php get_footer(); ?>
