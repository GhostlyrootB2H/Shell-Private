<?php
/**
 * The header template.
 *
 * Displays everything up to the opening of the main content '<div class="container">'.
 *
 * @package SKT_Lace
 */
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php if ( is_singular() && pings_open( get_queried_object() ) ) : ?>
	<link rel="pingback" href="<?php echo esc_url( get_bloginfo( 'pingback_url' ) ); ?>">
<?php endif; ?>
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php
if ( function_exists( 'wp_body_open' ) ) {
	wp_body_open();
} else {
	do_action( 'wp_body_open' );
}
?>
<a class="skip-link screen-reader-text" href="#content_navigator">
	<?php esc_html_e( 'Skip to content', 'skt-lace' ); ?>
</a>
<?php
$showpagebanner   = esc_html(get_theme_mod('inner_page_banner_option', 1 ));
$showpostbanner   = esc_html(get_theme_mod('inner_post_banner_option', 1 ));
$pagethumb        = esc_html(get_theme_mod('inner_page_banner_thumb' ));
$postthumb        = esc_html(get_theme_mod('inner_post_banner_thumb' ));
$tpb_contact_no   = esc_html(get_theme_mod('contact_no'));
$tpb_contact_adrs = esc_html(get_theme_mod('contact_address'));
$tpb_contact_mail = esc_html(get_theme_mod('contact_mail'));
$tpb_fb_link      = esc_url(get_theme_mod('fb_link_scl')); 
$tpb_ytb_link   = esc_url(get_theme_mod('youtube_link_scl'));
$tpb_linked_link  = esc_url(get_theme_mod('linked_link_scl'));
$tpb_insta_link   = esc_url(get_theme_mod('insta_link_scl'));
$hidetopbar       = esc_html(get_theme_mod('hide_header_topbar', 1));
$headerbtn        = esc_html(get_theme_mod('header_btntext' ));
$headerbtnlink    = esc_url(get_theme_mod('header_btn_link' ));
$hideheaderbtn    = esc_html(get_theme_mod('hide_header_button', 1 ));
$hideheaderscl    = esc_html(get_theme_mod('hide_header_social', 1 ));
?>
<div id="main-set">


	<div class="header">
    <div class="head-bar">
        <div class="container">
        	<div class="header-parts">
            	<?php if( $hideheaderscl == '') { ?>
				<div class="header-social">
                    <div class="social-icons">
                        <?php if ( !empty($tpb_fb_link) ) : ?>
                            <a class="fb" target="_blank" href="<?php echo esc_url($tpb_fb_link); ?>" title="<?php esc_attr_e('Facebook','skt-lace'); ?>"></a>
                        <?php endif; ?>
                        <?php if ( !empty($tpb_ytb_link) ) : ?>
                            <a class="ytb" target="_blank" href="<?php echo esc_url($tpb_ytb_link); ?>" title="<?php esc_attr_e('YoutTube','skt-lace'); ?>"></a>
                        <?php endif; ?>
                        <?php if ( !empty($tpb_linked_link) ) : ?>
                            <a class="in" target="_blank" href="<?php echo esc_url($tpb_linked_link); ?>" title="<?php esc_attr_e('LinkedIn','skt-lace'); ?>"></a>
                        <?php endif; ?>
                        <?php if ( !empty($tpb_insta_link) ) : ?>
                            <a class="insta" target="_blank" href="<?php echo esc_url($tpb_insta_link); ?>" title="<?php esc_attr_e('Instagram','skt-lace'); ?>"></a>
                        <?php endif; ?>
                    </div>
                </div>
                <?php } ?>
                <div class="header-logo">
                	<div class="logo">
				<?php if ( has_custom_logo() ) : ?>
            
                    <?php skt_lace_the_custom_logo(); ?>
            
                    <?php 
                    $description = get_bloginfo( 'description', 'display' );
                    if ( $description || is_customize_preview() ) : ?>
                        <p class="site-description"><?php echo esc_html( $description ); ?></p>
                    <?php endif; ?>
            
                <?php else : ?>
            
                    <div id="logo-main">
                        <a href="<?php echo esc_url( home_url( '/' ) ); ?>">
                            <h2 class="site-title"><?php bloginfo( 'name' ); ?></h2>
            
                            <?php 
                            $description = get_bloginfo( 'description', 'display' );
                            if ( $description || is_customize_preview() ) : ?>
                                <p class="site-description"><?php echo esc_html( $description ); ?></p>
                            <?php endif; ?>
                        </a>
                    </div>
            
                <?php endif; ?>
            </div>
                </div>
                <div class="header-sac">
                        <img class="search-toggle" src="<?php echo esc_url(get_stylesheet_directory_uri());?>/images/search-icon.png"/>
                        <form method="get" class="search-form" action="<?php echo esc_url( home_url( '/' ) ); ?>">
                          <input type="search" class="search-field" placeholder="<?php esc_attr_e( 'Search', 'skt-lace' ); ?>" name="s">
                          <input type="submit" class="search-submit" value="<?php esc_attr_e( 'Search', 'skt-lace' ); ?>">
                        </form>
						<?php if ( class_exists( 'WooCommerce' ) ) { ?><a href="<?php echo esc_url(get_permalink( wc_get_page_id( 'myaccount' ) )); ?>
                        " title="<?php esc_attr_e( 'My Account', 'skt-lace' ); ?>"><img src="<?php echo esc_url(get_stylesheet_directory_uri());?>/images/user-image.png" /></a><?php } ?>
						<?php if ( class_exists( 'WooCommerce' ) ) { ?>
                        <a class="cart-customlocation" href="<?php echo esc_url( wc_get_cart_url() ); ?>" title="<?php esc_attr_e( 'View shopping cart', 'skt-lace' ); ?>"> <img class="cart-customlocation" src="<?php echo esc_url(get_stylesheet_directory_uri());?>/images/cart-image.png" /> <span class="custom-cart-count"><?php echo wp_kses_data( WC()->cart->get_cart_contents_count() ); ?></span> </a><?php } ?>
  				</div>
                <div class="clear"></div>            
            </div>
            <div class="clear"></div>
            <!-- LOGO -->
        </div>
    </div>

</div><!-- /.header -->
	
	<div class="navigbar">
    	<div class="container">
    	<!-- NAVIGATION -->
            <div id="navigation">
                <nav id="site-navigation" class="main-navigation">
                    <button type="button" class="menu-toggle" aria-label="Toggle Menu">
                        <span></span>
                        <span></span>
                        <span></span>
                    </button>

                    <?php
                    wp_nav_menu(array(
                        'theme_location' => 'primary',
                        'container'      => false,
                        'menu_id'        => 'primary',
                        'menu_class'     => 'primary-menu menu'
                    ));
                    ?>
                </nav>               
            </div>
    </div>
</div>
</div><!-- /#main-set -->

<?php
/* Inner page banner. */
if ( ! is_home() && ! is_front_page() && is_page() ) :
	?>
	<div class="clear"></div>
	<div class="inner-banner-thumb">
		<?php if ( empty( $showpagebanner ) ) : ?>
			<?php
			if ( has_post_thumbnail() ) {
				the_post_thumbnail( 'full' );
			} elseif ( ! empty( $pagethumb ) ) {
				?>
				<img src="<?php echo esc_url( $pagethumb ); ?>" alt="" />
				<?php
			}
			?>
		<?php endif; ?>
		<div class="banner-container"><h1><?php the_title(); ?></h1></div>
		<div class="clear"></div>
	</div>
	<div class="clear"></div>
	<?php
endif;

/* Single post banner. */
if ( ! is_home() && ! is_front_page() && ! is_page() && is_single() && 'post' === get_post_type() ) :
	?>
	<div class="clear"></div>
	<div class="inner-banner-thumb">
		<?php if ( empty( $showpostbanner ) ) : ?>
			<?php
			if ( has_post_thumbnail() ) {
				the_post_thumbnail( 'full' );
			} elseif ( ! empty( $postthumb ) ) {
				?>
				<img src="<?php echo esc_url( $postthumb ); ?>" alt="" />
				<?php
			}
			?>
		<?php endif; ?>
		<div class="banner-container"><h1><?php the_title(); ?></h1></div>
		<div class="clear"></div>
	</div>
	<?php
endif;

/* Category / Archive / Shop banner. */
if ( is_category() || is_archive() ) :
	?>
	<div class="clear"></div>
	<div class="inner-banner-thumb">
		<?php if ( empty( $showpostbanner ) && ! empty( $postthumb ) ) : ?>
			<img src="<?php echo esc_url( $postthumb ); ?>" alt="" />
		<?php endif; ?>
		<div class="banner-container">
			<?php
			if ( class_exists( 'WooCommerce' ) && function_exists( 'is_shop' ) && is_shop() ) {
				?><h1><?php woocommerce_page_title(); ?></h1><?php
			} else {
				?><h1><?php the_archive_title(); ?></h1><?php
			}
			?>
		</div>
		<div class="clear"></div>
	</div>
	<?php
endif;
?>
<div class="clear"></div>