<?php
/**
 * The main template file.
 *
 * @package SKT_Lace
 */

get_header(); ?>

<div class="container">
	<div id="content_navigator">
		<div class="page_content">
			<section class="site-main">
				<div class="blog-post">
					<div class="blogpost-wrap-wsb">
						<?php if ( have_posts() ) : ?>
							<?php
							while ( have_posts() ) :
								the_post();
								get_template_part( 'content', get_post_format() );
							endwhile;
							?>
					</div><!-- /.blogpost-wrap-wsb -->
					<?php
					the_posts_pagination(
						array(
							'mid_size'  => 2,
							'prev_text' => esc_html__( 'Back', 'skt-lace' ),
							'next_text' => esc_html__( 'Next', 'skt-lace' ),
						)
					);
					?>
				<?php else : ?>
					</div><!-- /.blogpost-wrap-wsb -->
					<?php get_template_part( 'no-results' ); ?>
				<?php endif; ?>
				</div><!-- /.blog-post -->
			</section>
			<?php get_sidebar(); ?>
			<div class="clear"></div>
		</div><!-- /.page_content -->
	</div><!-- /#content_navigator -->
</div><!-- /.container -->

<?php get_footer(); ?>
