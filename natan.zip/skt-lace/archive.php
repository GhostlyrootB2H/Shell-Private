<?php
/**
 * The template for displaying archive pages.
 *
 * @package SKT_Lace
 */

get_header(); ?>

<div class="container">
	<div id="content_navigator">
		<div class="page_content">
			<section class="site-main">
				<?php if ( have_posts() ) : ?>
					<div class="blog-post">
						<div class="blogpost-wrap-wsb">
							<?php
							while ( have_posts() ) :
								the_post();
								get_template_part( 'content', get_post_format() );
							endwhile;
							?>
						</div>
					</div>
					<?php
					the_posts_pagination(
						array(
							'mid_size'           => 2,
							'prev_text'          => esc_html__( 'Back', 'skt-lace' ),
							'next_text'          => esc_html__( 'Next', 'skt-lace' ),
							'screen_reader_text' => esc_html__( 'Posts navigation', 'skt-lace' ),
						)
					);
					?>
				<?php else : ?>
					<?php get_template_part( 'no-results' ); ?>
				<?php endif; ?>
			</section>
			<?php get_sidebar(); ?>
			<div class="clear"></div>
		</div><!-- /.page_content -->
	</div><!-- /#content_navigator -->
</div><!-- /.container -->

<?php get_footer(); ?>
